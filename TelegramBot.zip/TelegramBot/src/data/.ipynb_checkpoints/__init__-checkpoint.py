from pathlib import Path
DATA_DIR = Path(__file__).resolve().parent